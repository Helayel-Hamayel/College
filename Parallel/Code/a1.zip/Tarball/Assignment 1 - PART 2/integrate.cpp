#include <iostream>
#include "func.cpp"
using namespace std;

double Trap(double left_endpt, double right_endpt, int trap_count, double base_len) {
   double estimate, x;
   int i;

   estimate = (func(left_endpt) + func(right_endpt))/2.0;
   for (i = 1; i <= trap_count-1; i++) 
   {
      x = left_endpt + i*base_len;
      estimate += func(x);
   }
   estimate = estimate*base_len;

   return estimate;
} 


int main(int argc, char** argv) {

   double a,b;
   int n;

/*
   cout<<"\n[x] Insert the left endpoint (a) => ";
   cin>>a;

   cout<<"\n[x] Insert the right endpoint (b) => ";
   cin>>b;

   cout<<"\n[x] Insert the trapezoids (n)\n[the higher, the more accurate/closer to answer] => ";
   cin>>n;
*/

   a = atoi(argv[1]);     
   b = atoi(argv[2]);
   n = atoi(argv[3]);

   if(b>a)
   {
   double h;
   double total_int;
  
   h = (b-a)/n; 
 
   total_int = Trap(a,b,n,h);

   cout<<"\nwith n = "<<n<<" trapezoids, our estimate of the area integral from "<<a<<" to "<<b
       <<endl<<"is "<<total_int<<endl<<endl;
   }
   else if(b==a){cout<<"\nThe area integral is 0, due point a equals point b\n\n";}

   return 0;
} 



