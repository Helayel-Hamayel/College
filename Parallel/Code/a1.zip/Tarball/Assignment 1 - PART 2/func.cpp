#include <iostream>
#include <math.h> 

using namespace std;

double func(double x)
{
double result= pow(x,2)+3*x+10;
return result;
}

