#include <iostream>
#include <mpi.h>
using namespace std;
int main(int argc, char **argv) 
{
MPI_Init(&argc, &argv);

int rank, size,len;
char* name;

MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);
MPI_Get_processor_name(name, &len);

if(rank%2==0)//even
{
cout <<"["<<rank<<"] hello from "<<rank<<" out of "<<size<<" ["<<name<<"]"<< endl;
}
else if(rank%2==1)//odd
{
cout <<"["<<rank<<"] hi from "<<rank<<" out of "<<size<<" ["<<name<<"]"<< endl;
}

MPI_Finalize();
return 0;
}
