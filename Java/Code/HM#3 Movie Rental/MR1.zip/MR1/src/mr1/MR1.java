/*
Your are to write a complete Java class that will have a menu.

The menu should have to entries.

File Operations

===================================================

{Files will have the following menu items}

import

export

exit

===================================================

{Operations will have the following menu tems}

Add a new video

Delete a video

rent a video

return a video.

===================================================

{Search}

Search for a video

search for a customer 

Display All

===================================================

{information for a given video shall be}

Movie_Name

Length

Rate 

Date released

Rented to?

Date of rental

Date of return

Category 

*/


package mr1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.*;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.table.DefaultTableModel;

public class MR1 extends JFrame implements ActionListener {

    static ResultSet RS= null;
    static Connection CON = null;
    static Statement ST = null;
    static PreparedStatement PST = null;
    
    
    
    public static Connection getCon() throws Exception
    {   
    String userDir = System.getProperty("user.home")+"\\Desktop";
    System.out.println(userDir);    
        
    String URL="jdbc:ucanaccess://"+userDir+"\\MovieRenting.accdb"; 
    System.out.println(URL);
    System.out.println("Connected");
    
    return DriverManager.getConnection(URL);
    }
  

    JMenuBar B;
    JMenu Files,Video,Search;
    JMenuItem Import,Export,Exit; // For FILES
    JMenuItem Add,Delete,Rent,Return; // FOR VIDEO
    JMenuItem ByV, ByC,DA;// FOR SEARCH
    JLabel M,R;
    DefaultTableModel model1,model2;

    
    
    public MR1()
    {
    super("Movie Rental");
    
    M=new JLabel("Movies                                                                                                                                                                       Rents");
    
    
    
    
    B=new JMenuBar();
    setJMenuBar(B);
    
    Files=new JMenu("File");
    Video=new JMenu("Video");
    Search=new JMenu("Search");
    
    B.add(Files);
    B.add(Video);
    B.add(Search);
    
    Import = new JMenuItem("Import");
    Export = new JMenuItem("Export");
    Exit = new JMenuItem("Exit");
    
    Files.add(Import);
    Files.add(Export);
    Files.addSeparator();
    Files.add(Exit);
    
    Add= new JMenuItem("Add a new Video");
    Delete = new JMenuItem("Delete a Video");
    Rent = new JMenuItem("Rent a Video");
    Return = new JMenuItem("Return a Video");
    
    Video.add(Add);
    Video.add(Delete);
    Video.addSeparator();
    Video.add(Rent);
    Video.add(Return);
    
    ByV = new JMenuItem("By Movie");
    ByC = new JMenuItem("By Renter");
    DA = new JMenuItem("Display All");
    
    Search.add(ByV);
    Search.add(ByC);
    Search.addSeparator();
    Search.add(DA);
    
    
    Exit.addActionListener(this); 
    ByC.addActionListener(this);
    ByV.addActionListener(this);
    DA.addActionListener(this); 
    Add.addActionListener(this);
    Delete.addActionListener(this);
    Rent.addActionListener(this);
    Return.addActionListener(this);
    Import.addActionListener(this);
    Export.addActionListener(this);
    
    
    //for the tables of MOVIES AND RENT
    model1 = new DefaultTableModel(); 
    model1.addColumn("Movie_Name"); 
    model1.addColumn("Length"); 
    model1.addColumn("Catagory"); 
    model1.addColumn("Release Date");
    model1.addColumn("Rate");
    
    
    JTable table1 = new JTable(model1); 
    
    JScrollPane scrollPane1 = new JScrollPane(table1);
    add(M, BorderLayout.NORTH);
    add(scrollPane1, BorderLayout.WEST);
    
    
    model2 = new DefaultTableModel(); 
    model2.addColumn("Movie_Name"); 
    model2.addColumn("Rented_By"); 
    model2.addColumn("Date Of Rentering"); 
    model2.addColumn("Date Of Return");
   
    JTable table2 = new JTable(model2);

    JScrollPane scrollPane2 = new JScrollPane(table2);
    add(scrollPane2, BorderLayout.EAST);
    
    
    
    
    setResizable(false);
    setSize(1000,250);
    setLocation(200,100);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setVisible(true);
    }
    
    
    
    
   
    
    
    public static void main(String[] args) throws Exception 
    {
        new MR1();  
    }

    @Override
    public void actionPerformed(ActionEvent e)  {
        
        String userDir = System.getProperty("user.home");
        JFileChooser jf = new JFileChooser(userDir +"/Desktop");
        
        FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
        jf.setFileFilter(filter);
        
        try 
        {
            CON=getCon();
            ST=CON.createStatement();
        } catch (Exception ex) 
        {}
 
        Object M = e.getSource();
        if(M==Exit)
        {
            dispose();
        }
        
        if(M==Import)
        {
        
        try 
        {

        int returnVal = jf.showOpenDialog(null);
        
        if (returnVal == JFileChooser.APPROVE_OPTION)
        {
        File T = jf.getSelectedFile();
        System.out.println("chossen file is "+jf.getSelectedFile());
        
        Scanner sp = new Scanner(T);
        Scanner in = new Scanner(T);
        Scanner E  = new Scanner(T);
        in.useDelimiter("\",\"|\"");
 
        if(sp.hasNext("Movies"))
        {System.out.println(sp.next());}
        sp.nextLine(); 
        E.nextLine();
        E.nextLine();
        int lock = 0;
        
        
        System.out.println("STORED IN MOVIES");
        
        while(in.hasNext()&&!(in.next().equals(" ")))
        { 
          if(!(sp.hasNext("Rent"))&&lock==0)
          { 

          String S4="INSERT INTO Movies VALUES ("; 
    
               S4=S4+"'"+in.next()+"'"+",";
               S4=S4+"'"+in.next()+"'"+",";
               S4=S4+"'"+in.next()+"'"+",";
               S4=S4+"'"+in.next()+"'"+",";
               S4=S4+"'"+in.next()+"'"+")";
          
               ST.execute(S4);
          
          sp.nextLine(); 
          E.nextLine();
          
          }
          else if(!(E.hasNext("END")))
           {
           lock=1;   
           if(sp.hasNext("Rent"))
           {
           System.out.println(sp.next());
           System.out.println("STORED IN RENT");
           }
           
           sp.nextLine();
           
           
           sp.useDelimiter("\",\"|\"");   

        String S4="INSERT INTO Rent VALUES ("; 
    
               S4=S4+"'"+sp.next()+"'"+",";
               S4=S4+"'"+sp.next()+"'"+",";
               S4=S4+"'"+sp.next()+"'"+",";
               S4=S4+"'"+sp.next()+"'"+")";
          
               ST.execute(S4);
                     
           E.nextLine();
          }
   
        }
        }        
        } catch (Exception ex) 
        {}
         
        }
        
        if(M==Export)
        {
        try{
                
        int returnVal = jf.showSaveDialog(null);
        
        if (returnVal == JFileChooser.APPROVE_OPTION)
        {
        File T = jf.getSelectedFile();
        System.out.println("chossen file is "+jf.getSelectedFile());
        
        if(!T.exists())
        {
        T.createNewFile();
        }
        
        PrintStream P = new PrintStream(jf.getSelectedFile());

        String S1="SELECT * from Movies";
        
        
        RS=ST.executeQuery(S1);//Movies
            P.println("Movies");
            while(RS.next())
            {
               P.println("\""+RS.getString(1)+"\",\""+RS.getString(2)+"\",\""+RS.getString(3)+"\",\""+RS.getString(4)+"\",\""+RS.getString(5)+"\"");   
            }
            RS=null;
            P.print("\n");
            
            
        String S2="SELECT * from Rent";    
        RS=ST.executeQuery(S2);//Rent
        P.println("Rent");
            while(RS.next())
            {
               
            
            while(RS.next())
            {
               P.println("\""+RS.getString(1)+"\",\""+RS.getString(2)+"\",\""+RS.getString(3)+"\",\""+RS.getString(4)+"\"");   
            }
                
            }        
        P.println("END");
        }    
           } 
       catch (Exception ex){}
        
        }
        
 
        
        
        if(M==ByV)
        {
            String VideoName = JOptionPane.showInputDialog("Insert The Video's Name to Search");
            model1.setRowCount(0);
            String S1="SELECT * from Movies";
            
            try {
                RS=ST.executeQuery(S1);
                while(RS.next())
                {
                if(RS.getString(1).equalsIgnoreCase(VideoName))   
                   model1.addRow(new Object[]{RS.getString(1), RS.getString(2),RS.getString(3),RS.getString(4),RS.getString(5)});
                }
                
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "SUCH A THING DOES NOT EXIST", "Warning", JOptionPane.WARNING_MESSAGE); 
            }
                 
        
            
        }
        
        if(M==ByC)
        {
            String CustomerName = JOptionPane.showInputDialog("Insert The Customer's Name to Search");
           
            model2.setRowCount(0);
            String S2="SELECT * from Rent";
            
        try {
                RS=ST.executeQuery(S2);
                while(RS.next())
                {
                if(RS.getString(2).equalsIgnoreCase(CustomerName))   
                   model2.addRow(new Object[]{RS.getString(1), RS.getString(2),RS.getString(3),RS.getString(4)});
                } 
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "SUCH A THING DOES NOT EXIST", "Warning", JOptionPane.WARNING_MESSAGE);
            }   
        
        
        
        }
        
        if(M==DA)
        {
        //DISPLAYS ALL THE DATABASE TO TABLE
            model1.setRowCount(0);
           
            String S1="SELECT * from Movies";
            
            try {
                RS=ST.executeQuery(S1);
                while(RS.next())
                {
                  model1.addRow(new Object[]{RS.getString(1), RS.getString(2),RS.getString(3),RS.getString(4),RS.getString(5)});
                }
                
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "SUCH A THING DOES NOT EXIST", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            
            RS=null;
            model2.setRowCount(0);
            String S2="SELECT * from Rent";
            
        try {
                RS=ST.executeQuery(S2);
                while(RS.next())
                {  
                   model2.addRow(new Object[]{RS.getString(1), RS.getString(2),RS.getString(3),RS.getString(4)});
                } 
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "SUCH A THING DOES NOT EXIST", "Warning", JOptionPane.WARNING_MESSAGE);
            }   
            
        }
        
        if(M==Add)
        {
            
            String[] Catagory = {"Action","Adult","Adventure","Comedy","Crime","Drama", "Documentary","Family","Horror","Science-Fiction", "Romance", "Mystery","Western"};  
            JComboBox List = new JComboBox(Catagory);
         
            
            
            JLabel L = new JLabel("Insert Movie's Information");
            JTextField field1 = new JTextField();
            JTextField field2 = new JTextField();
            JTextField field3 = new JTextField();
            JTextField field4 = new JTextField(); //YEAR-MONTH-DAY

            Object[] AM = {
                           L,  
                           "Movie_Name:", field1,
                           "Lenght:", field2,
                           "Rate:", field3,
                           "Release Date:", field4,
                           "Catagory", List,
                          };

            int option = JOptionPane.showConfirmDialog(null, AM, "Adding a Movie", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION)
            {
               String AMN = field1.getText();
               String AL = field2.getText();
               String AR = field3.getText();
               String ADR = field4.getText();
               String AC = (String) List.getSelectedItem();
               
               
               //PROCCEEDING TO ADD A NEW ROW IN MOVIE TABLE
               
               
               String S4="INSERT INTO Movies VALUES ("; 
    
               S4=S4+"'"+AMN+"'"+",";
               S4=S4+"'"+AL+"'"+",";
               S4=S4+"'"+AC+"'"+",";
               S4=S4+"'"+ADR+"'"+",";
               S4=S4+"'"+AR+"'"+")";
        
                try {
                    ST.execute(S4);
                    JOptionPane.showMessageDialog(null, "The Insertion is a Success", "Success", JOptionPane.INFORMATION_MESSAGE); 
                } catch (SQLException ex) {
                     JOptionPane.showMessageDialog(null, "The Insertion is a FAILURE", "Warning", JOptionPane.WARNING_MESSAGE); 
                }
 
            }
            
        }
        
        if(M==Delete)
        {
            
            JTextField field1 = new JTextField();
            Object[] Delet = {"Movie_Name to Delete:", field1};
            
            
            int Del = JOptionPane.showConfirmDialog(null, Delet, "Deleting a Movie", JOptionPane.OK_CANCEL_OPTION);
           
            if (Del == JOptionPane.OK_OPTION)
            {
               String MN = field1.getText().trim();
               ///// proceed deleting the row of the Movie_Name FROM THE MOVIES TABLE
               
               
               
       
       try {
           RS=ST.executeQuery("SELECT * from Movies where Movie_Name = "+"'"+MN+"'");
        if(RS.next()==false)
            JOptionPane.showMessageDialog(null, "Such a thing DOES NOT EXIST", "Warning", JOptionPane.WARNING_MESSAGE);
        else
        {
        ST.executeUpdate("DELETE from Movies where Movie_Name = "+"'"+MN+"'");
        }
               
         } 
               catch (Exception ex) 
              {
              JOptionPane.showMessageDialog(null, "Such a thing DOES NOT EXIST", "Warning", JOptionPane.WARNING_MESSAGE);
              ex.printStackTrace();
              }     
           }  
         
        }
        
        if(M==Return)
        {
          JTextField field1 = new JTextField();
          JTextField field2 = new JTextField();
            
          Object[] Ret = {
                "Movie to Return:", field1,
                "Rented_By:",field2  
            };
          
          int R = JOptionPane.showConfirmDialog(null, Ret, "Return a Movie", JOptionPane.OK_CANCEL_OPTION);
           
           if (R == JOptionPane.OK_OPTION)
           {
               
               
               String ReMN = field1.getText();
               String ReBC = field2.getText();
               //THEN IT PROCCEIDNG TO UPDATE THE ROW OF CONDITON FROM RENTED TO AVIALIABLE AND RENTED BY FROM SOMEONE TO NONE.

              try 
              {  
                String Returns="SELECT * from Rent where Movie_Name = '"+ReMN+"' and Rented_By = '"+ReBC+"'";  
                RS=ST.executeQuery(Returns);
    
                if(RS.next()==false)
                JOptionPane.showMessageDialog(null, "Such a thing DOES NOT EXIST", "Warning", JOptionPane.WARNING_MESSAGE);
                else
                {
                ST.executeUpdate("DELETE from Rent where Movie_Name = '"+ReMN+"' and Rented_By = '"+ReBC+"'");
                JOptionPane.showMessageDialog(null, "The DELETION is a Success", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
                  
                  
              } catch (SQLException ex) 
              {
               JOptionPane.showMessageDialog(null, "Such a thing DOES NOT EXIST", "Warning", JOptionPane.WARNING_MESSAGE);
              }   
           }  
          
        }
        
        
        
        
        
        
        
        
    }
    
}
